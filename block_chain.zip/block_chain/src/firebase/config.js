import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// const firebaseConfig = {
//   apiKey: "AIzaSyBSgSLP77V-4GXIJVHurqQuqa8jXAS3kHo",
//   authDomain: "blockchain-b089c.firebaseapp.com",
//   projectId: "blockchain-b089c",
//   storageBucket: "blockchain-b089c.firebasestorage.app",
//   messagingSenderId: "670032236476",
//   appId: "1:670032236476:web:8c08d6d6615ecbd3de25b9"
// };

// 陈雨龙：
	0x0Ac8eCdFd81912f91c992ef5A4e94a8aC25436cd

// Ling Yi：
	// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAjdLnwWxBHoYCkB_sjz4mgAEXOh6Iyuy0",
  authDomain: "nftmarketlite.firebaseapp.com",
  projectId: "nftmarketlite",
  storageBucket: "nftmarketlite.firebasestorage.app",
  messagingSenderId: "81978989441",
  appId: "1:81978989441:web:53f39e3fe4fe19d9cf6680"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app); 